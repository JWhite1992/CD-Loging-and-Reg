from flask import request, render_template, redirect, session, flash
from flask_bcrypt import Bcrypt
from flask_app import app
from flask_app.models.models_logger import User

bcrypt = Bcrypt(app)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['POST'])
def register():
    if not User.validate_member(request.form):
        return redirect('/')
    # Hash the password
    hashed_password = bcrypt.generate_password_hash(request.form['password'])
    # Create a dictionary with the form data
    user_data = {
        'first_name': request.form['first_name'],
        'last_name': request.form['last_name'],
        'email': request.form['email'],
        'password': hashed_password
    }
    # Save the user to the database
    user_id = User.save(user_data)
    # Store the user_id in the session
    session['user_id'] = user_id
    return redirect('/welcome')

@app.route('/login', methods=['POST'])
def login():
    # See if the email provided exists in the database
    user = User.get_by_email(request.form)
    if not user:
        flash("Invalid Email/Password", "login")
        return redirect('/')
    # Check if the password matches
    if not bcrypt.check_password_hash(user.password, request.form['password']):
        flash("Invalid Email/Password", "login")
        return redirect('/')
    # Store the user_id in the session
    session['user_id'] = user.id
    return redirect('/welcome')

@app.route('/welcome')
def welcome():
    # Retrieve the user from the database based on the user_id in the session
    user = User.get_by_id({'id': session['user_id']})
    return render_template('welcome.html', user=user)




@app.route('/logout')
def logout():
    # Clear the user_id from the session
    session.clear()
    return redirect('/')
